import React, { useState, useRef, useEffect, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../App'
import { api } from '../utils/api'
import { parseFile, ACCEPTED_TYPES, getFileIcon } from '../utils/fileParser'

/* ═══════════════════════════════════════════════
   Workspace — Resume + JD input, pipeline run
   ═══════════════════════════════════════════════ */

const AGENTS = [
  { id: 'analyzer', icon: '🔍', name: '分析师', model: 'DeepSeek-V3.2' },
  { id: 'matcher', icon: '🎯', name: '匹配官', model: 'Kimi-K2.5' },
  { id: 'optimizer', icon: '✍️', name: '重写师', model: 'Qwen3.5' },
  { id: 'polisher', icon: '💎', name: '润色师', model: 'GLM-5.1' },
  { id: 'coach', icon: '🎓', name: '面试教练', model: 'MiniMax-M2.5' },
  { id: 'verifier', icon: '✅', name: '审核官', model: 'DeepSeek-V3.2' },
]

const css = `
  .workspace {
    max-width: 720px; margin: 0 auto;
    padding: 16px; min-height: calc(100vh - 52px);
  }
  .ws-title {
    font-size: 24px; font-weight: 700;
    margin: 16px 0 4px; color: #1C1C1E;
    letter-spacing: -0.5px;
  }
  .ws-sub {
    font-size: 14px; color: #8E8E93;
    margin-bottom: 20px;
  }
  .ws-section {
    background: #fff; border-radius: 16px;
    padding: 20px; margin-bottom: 14px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.04);
  }
  .ws-label {
    font-size: 15px; font-weight: 600;
    color: #1C1C1E; margin-bottom: 10px;
    display: flex; align-items: center; gap: 6px;
  }
  .ws-textarea {
    width: 100%; min-height: 140px;
    padding: 14px 16px; background: #F2F2F7;
    border-radius: 12px; border: 1.5px solid transparent;
    font-size: 15px; color: #1C1C1E;
    line-height: 1.6; resize: none;
    font-family: inherit; outline: none;
    transition: all 0.2s;
  }
  .ws-textarea:focus {
    background: #fff; border-color: #007AFF;
    box-shadow: 0 0 0 3px rgba(0,122,255,0.1);
  }
  .ws-textarea::placeholder { color: #AEAEB2; }

  /* File upload */
  .upload-zone {
    border: 2px dashed #E5E5EA; border-radius: 12px;
    padding: 20px; text-align: center;
    cursor: pointer; transition: all 0.2s;
    margin-top: 10px;
  }
  .upload-zone:hover { border-color: #007AFF; background: #F8FBFF; }
  .upload-zone.active { border-color: #007AFF; background: #E3F0FF; }
  .upload-icon { font-size: 28px; margin-bottom: 6px; }
  .upload-text { font-size: 13px; color: #8E8E93; }
  .upload-text b { color: #007AFF; }
  .file-chip {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 6px 12px; border-radius: 999px;
    background: #E3F0FF; font-size: 13px;
    color: #007AFF; font-weight: 500;
    margin-top: 8px;
  }
  .file-chip button {
    background: none; border: none;
    font-size: 14px; cursor: pointer;
    color: #8E8E93;
  }

  /* Pipeline */
  .ws-pipeline {
    display: flex; align-items: center;
    justify-content: center; gap: 0;
    padding: 20px 0; overflow-x: auto;
    -webkit-overflow-scrolling: touch;
  }
  .ws-pipe-node {
    display: flex; flex-direction: column;
    align-items: center; gap: 6px;
    flex-shrink: 0;
  }
  .ws-pipe-circle {
    width: 44px; height: 44px; border-radius: 50%;
    display: flex; align-items: center;
    justify-content: center; font-size: 18px;
    transition: all 0.5s;
  }
  .ws-pipe-circle.idle { background: #F2F2F7; }
  .ws-pipe-circle.running {
    background: #E3F0FF;
    animation: pulse 1.5s ease-in-out infinite;
  }
  .ws-pipe-circle.done { background: #E8F9ED; }
  .ws-pipe-circle.error { background: #FFE5E3; }
  .ws-pipe-name {
    font-size: 10px; color: #8E8E93;
    font-weight: 500; white-space: nowrap;
  }
  .ws-pipe-line {
    width: 20px; height: 2px;
    background: #E5E5EA; flex-shrink: 0;
    margin-bottom: 20px;
    transition: background 0.4s;
  }
  .ws-pipe-line.done { background: #34C759; }

  /* Run button */
  .ws-run-btn {
    width: 100%; padding: 16px;
    border-radius: 999px; border: none;
    font-size: 17px; font-weight: 600;
    cursor: pointer; transition: all 0.25s;
    display: flex; align-items: center;
    justify-content: center; gap: 8px;
  }
  .ws-run-btn.ready {
    background: #007AFF; color: #fff;
    box-shadow: 0 4px 14px rgba(0,122,255,0.3);
  }
  .ws-run-btn.ready:active { transform: scale(0.97); }
  .ws-run-btn.running {
    background: #F2F2F7; color: #8E8E93;
    cursor: not-allowed;
  }
  .ws-run-btn.disabled {
    background: #F2F2F7; color: #AEAEB2;
    cursor: not-allowed;
  }

  /* Status messages */
  .ws-status {
    text-align: center; font-size: 14px;
    color: #8E8E93; margin-top: 12px;
    min-height: 20px;
  }

  /* Quick fill */
  .quick-bar {
    display: flex; gap: 8px; margin-bottom: 12px;
    flex-wrap: wrap;
  }
  .quick-tag {
    padding: 6px 14px; border-radius: 999px;
    background: #F2F2F7; border: none;
    font-size: 12px; color: #8E8E93;
    cursor: pointer; transition: all 0.2s;
    font-weight: 500;
  }
  .quick-tag:active { background: #E5E5EA; }

  @keyframes pulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(0,122,255,0.25); }
    50% { box-shadow: 0 0 0 8px rgba(0,122,255,0); }
  }

  @media (max-width: 390px) {
    .ws-pipe-circle { width: 36px; height: 36px; font-size: 15px; }
    .ws-pipe-line { width: 14px; }
    .ws-textarea { min-height: 100px; font-size: 14px; }
  }
`

const SAMPLE_RESUME = `张三
zhangsan@email.com | 138-0000-0000 | 北京
求职意向: 高级前端开发工程师

【教育背景】
北京大学 计算机科学与技术 本科 2018-2022 GPA: 3.7/4.0

【工作经历】
ABC科技有限公司 - 前端开发工程师 (2022.07 - 至今)
- 负责公司核心产品的前端开发
- 参与了多个项目的技术方案设计
- 使用React框架进行组件开发
- 优化了页面性能

【技能】
JavaScript, React, Vue, TypeScript, CSS, Node.js`

const SAMPLE_JD = `【高级前端开发工程师】某互联网大厂 | 30-50K·16薪
岗位职责:
1. 负责核心业务系统前端架构设计与开发
2. 主导前端工程化建设，提升研发效能
任职要求:
1. 本科及以上，计算机相关专业
2. 5年+前端开发，3年+React经验
3. 熟悉前端性能优化`

export default function WorkspacePage() {
  const { user, credits, openPayment, setShowLogin } = useApp()
  const navigate = useNavigate()

  const [resume, setResume] = useState('')
  const [jd, setJd] = useState('')
  const [file, setFile] = useState(null)
  const [parsing, setParsing] = useState(false)
  const [running, setRunning] = useState(false)
  const [agentStates, setAgentStates] = useState(
    AGENTS.reduce((acc, a) => ({ ...acc, [a.id]: 'idle' }), {})
  )
  const [status, setStatus] = useState('')
  const fileRef = useRef(null)

  const handleFileSelect = async (e) => {
    const f = e.target.files?.[0]
    if (!f) return
    setFile(f)
    setParsing(true)
    try {
      const text = await parseFile(f)
      setResume(text)
    } catch (err) {
      setStatus('文件解析失败: ' + err.message)
    } finally {
      setParsing(false)
    }
  }

  const canRun = resume.trim().length > 20 && !running

  const handleRun = async () => {
    if (!user) { setShowLogin(true); return }
    if (credits <= 0) { openPayment('resume'); return }
    if (!canRun) return

    setRunning(true)
    setStatus('正在启动AI流水线...')

    // Reset all agents
    setAgentStates(AGENTS.reduce((acc, a) => ({ ...acc, [a.id]: 'idle' }), {}))

    try {
      // Simulate sequential pipeline with real API
      const results = {}

      for (let i = 0; i < AGENTS.length; i++) {
        const agent = AGENTS[i]
        setAgentStates(prev => ({ ...prev, [agent.id]: 'running' }))
        setStatus(`${agent.name} (${agent.model}) 正在工作...`)

        try {
          const res = await api.runPipeline(resume, jd, {
            agent: agent.id,
            step: i,
            previousResults: results,
          })
          results[agent.id] = res.result
          setAgentStates(prev => ({ ...prev, [agent.id]: 'done' }))
        } catch (err) {
          setAgentStates(prev => ({ ...prev, [agent.id]: 'error' }))
          throw err
        }
      }

      // All done — navigate to result page
      setStatus('全部完成！正在生成报告...')
      // Store results for result page
      sessionStorage.setItem('rf_results', JSON.stringify(results))
      sessionStorage.setItem('rf_resume', resume)
      sessionStorage.setItem('rf_jd', jd)

      setTimeout(() => navigate('/result'), 500)
    } catch (err) {
      setStatus('出错了: ' + err.message)
    } finally {
      setRunning(false)
    }
  }

  return (
    <div className="workspace">
      <style>{css}</style>

      <div className="ws-title">简历优化工作台</div>
      <div className="ws-sub">粘贴简历或上传文件，AI 全自动帮你优化</div>

      {/* Quick fill */}
      <div className="quick-bar">
        <button className="quick-tag" onClick={() => { setResume(SAMPLE_RESUME); setJd(SAMPLE_JD) }}>
          📋 加载示例
        </button>
        <button className="quick-tag" onClick={() => { setResume(''); setJd(''); setFile(null) }}>
          🗑️ 清空
        </button>
      </div>

      {/* Resume Input */}
      <div className="ws-section">
        <div className="ws-label">📄 你的简历</div>
        <textarea
          className="ws-textarea"
          placeholder="粘贴你的简历内容...&#10;&#10;支持直接粘贴文本，或点击下方上传文件"
          value={resume}
          onChange={e => setResume(e.target.value)}
        />

        {/* File upload */}
        <input
          ref={fileRef}
          type="file"
          accept={ACCEPTED_TYPES}
          style={{ display: 'none' }}
          onChange={handleFileSelect}
        />
        <div
          className={`upload-zone ${parsing ? 'active' : ''}`}
          onClick={() => fileRef.current?.click()}
          onDragOver={e => { e.preventDefault(); e.currentTarget.classList.add('active') }}
          onDragLeave={e => e.currentTarget.classList.remove('active')}
          onDrop={e => {
            e.preventDefault()
            e.currentTarget.classList.remove('active')
            const f = e.dataTransfer.files?.[0]
            if (f) {
              setFile(f)
              parseFile(f).then(setResume).catch(() => {})
            }
          }}
        >
          <div className="upload-icon">{parsing ? '⏳' : '📎'}</div>
          <div className="upload-text">
            {parsing ? '正在解析文件...' : <>点击或拖拽上传 · <b>支持 txt/pdf/docx/图片</b></>}
          </div>
        </div>

        {file && !parsing && (
          <div className="file-chip">
            {getFileIcon(file.name)} {file.name}
            <button onClick={() => { setFile(null) }}>✕</button>
          </div>
        )}
      </div>

      {/* JD Input */}
      <div className="ws-section">
        <div className="ws-label">🎯 目标岗位JD <span style={{ fontSize: 12, color: '#AEAEB2', fontWeight: 400 }}>（选填，效果更好）</span></div>
        <textarea
          className="ws-textarea"
          style={{ minHeight: 100 }}
          placeholder="粘贴目标岗位的招聘JD...&#10;AI会根据JD针对性优化你的简历"
          value={jd}
          onChange={e => setJd(e.target.value)}
        />
      </div>

      {/* Pipeline Visualization */}
      <div className="ws-section">
        <div className="ws-label">🤖 AI 流水线</div>
        <div className="ws-pipeline">
          {AGENTS.map((agent, i) => (
            <React.Fragment key={agent.id}>
              <div className="ws-pipe-node">
                <div className={`ws-pipe-circle ${agentStates[agent.id]}`}>
                  {agentStates[agent.id] === 'done' ? '✓' :
                   agentStates[agent.id] === 'error' ? '✕' :
                   agent.icon}
                </div>
                <span className="ws-pipe-name">{agent.name}</span>
              </div>
              {i < AGENTS.length - 1 && (
                <div className={`ws-pipe-line ${agentStates[agent.id] === 'done' ? 'done' : ''}`} />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Run Button */}
      <button
        className={`ws-run-btn ${running ? 'running' : canRun ? 'ready' : 'disabled'}`}
        onClick={handleRun}
        disabled={!canRun || running}
      >
        {running ? (
          <>⏳ AI 正在工作中...</>
        ) : credits <= 0 ? (
          <>💎 充值后开始（¥1.99/次）</>
        ) : (
          <>🚀 开始优化（消耗1次 · 剩余 {credits} 次）</>
        )}
      </button>

      <div className="ws-status">{status}</div>
    </div>
  )
}
