import React, { useState } from 'react'
import { useApp } from '../App'

const css = `
  .interview {
    max-width: 720px; margin: 0 auto;
    padding: 16px; min-height: calc(100vh - 52px);
  }
  .iv-hero {
    text-align: center; padding: 32px 0 24px;
  }
  .iv-badge {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 6px 14px; border-radius: 999px;
    background: #FFF3E0; font-size: 13px;
    color: #FF9500; font-weight: 600;
    margin-bottom: 12px;
  }
  .iv-title {
    font-size: 28px; font-weight: 700;
    color: #1C1C1E; letter-spacing: -0.5px;
  }
  .iv-sub {
    font-size: 15px; color: #8E8E93;
    margin-top: 8px; line-height: 1.5;
  }
  .iv-features {
    display: grid; gap: 12px; margin: 24px 0;
  }
  .iv-feat {
    background: #fff; border-radius: 16px;
    padding: 18px 20px; display: flex;
    align-items: center; gap: 14px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.04);
  }
  .iv-feat-icon {
    width: 44px; height: 44px;
    border-radius: 12px; display: flex;
    align-items: center; justify-content: center;
    font-size: 22px; flex-shrink: 0;
  }
  .iv-feat h3 {
    font-size: 15px; font-weight: 600;
    color: #1C1C1E; margin-bottom: 2px;
  }
  .iv-feat p {
    font-size: 13px; color: #8E8E93;
  }
  .iv-section {
    background: #fff; border-radius: 16px;
    padding: 20px; margin-bottom: 14px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.04);
  }
  .iv-label {
    font-size: 15px; font-weight: 600;
    color: #1C1C1E; margin-bottom: 10px;
  }
  .iv-textarea {
    width: 100%; min-height: 120px;
    padding: 14px 16px; background: #F2F2F7;
    border-radius: 12px; border: 1.5px solid transparent;
    font-size: 15px; color: #1C1C1E;
    line-height: 1.6; resize: none;
    font-family: inherit; outline: none;
    transition: all 0.2s;
  }
  .iv-textarea:focus {
    background: #fff; border-color: #007AFF;
    box-shadow: 0 0 0 3px rgba(0,122,255,0.1);
  }
  .iv-start-btn {
    width: 100%; padding: 16px;
    border-radius: 999px; border: none;
    background: linear-gradient(135deg, #FF9500, #FF3B30);
    color: #fff; font-size: 17px; font-weight: 600;
    cursor: pointer; margin-top: 16px;
    box-shadow: 0 4px 14px rgba(255,149,0,0.3);
    transition: all 0.2s;
  }
  .iv-start-btn:active { transform: scale(0.97); }
  .iv-result {
    background: #fff; border-radius: 16px;
    padding: 20px; margin-top: 14px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.04);
    font-size: 14px; color: #3C3C43;
    line-height: 1.8; white-space: pre-wrap;
  }
`

const FEATURES = [
  { icon: '🎭', bg: '#F3E8FA', title: '谈薪剧本', desc: '3套话术应对HR压价，拿到满意数字' },
  { icon: '🧠', bg: '#E8F7FE', title: '逆向思维提问', desc: '用面试官思维反推答案，展现深度' },
  { icon: '💡', bg: '#FFF3E0', title: '高情商回答', desc: '50+常见刁钻问题的高分回答模板' },
  { icon: '📋', bg: '#E8F9ED', title: '14天冲刺计划', desc: '根据你的简历定制面试备考路径' },
  { icon: '⭐', bg: '#FFF3E0', title: 'STAR故事库', desc: '5个万能故事覆盖90%行为面试题' },
  { icon: '🎯', bg: '#E3F0FF', title: '多AI协作', desc: 'DeepSeek+Kimi+GLM多模型交叉辅导' },
]

export default function InterviewPage() {
  const { user, credits, openPayment, setShowLogin } = useApp()
  const [resume, setResume] = useState('')
  const [jd, setJd] = useState('')
  const [result, setResult] = useState('')
  const [running, setRunning] = useState(false)

  const handleStart = async () => {
    if (!user) { setShowLogin(true); return }
    openPayment('interview')
  }

  return (
    <div className="interview">
      <style>{css}</style>

      <div className="iv-hero">
        <div className="iv-badge">🔥 面试辅导</div>
        <h1 className="iv-title">拿到满意 Offer</h1>
        <p className="iv-sub">
          根据你的简历 + 目标岗位，多个AI协作<br/>
          生成完整面试备战方案
        </p>
      </div>

      <div className="iv-features">
        {FEATURES.map((f, i) => (
          <div className="iv-feat" key={i}>
            <div className="iv-feat-icon" style={{ background: f.bg }}>{f.icon}</div>
            <div>
              <h3>{f.title}</h3>
              <p>{f.desc}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="iv-section">
        <div className="iv-label">📄 你的简历（建议先用简历优化功能）</div>
        <textarea
          className="iv-textarea"
          placeholder="粘贴你的简历..."
          value={resume}
          onChange={e => setResume(e.target.value)}
        />
      </div>

      <div className="iv-section">
        <div className="iv-label">🎯 目标岗位JD</div>
        <textarea
          className="iv-textarea"
          style={{ minHeight: 80 }}
          placeholder="粘贴目标岗位招聘信息..."
          value={jd}
          onChange={e => setJd(e.target.value)}
        />
      </div>

      <button className="iv-start-btn" onClick={handleStart}>
        🚀 开始面试辅导（¥69.9/次）
      </button>

      {result && (
        <div className="iv-result">{result}</div>
      )}
    </div>
  )
}
