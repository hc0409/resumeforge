import React, { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'

/* ═══════════════════════════════════════════════
   Result Page — AI reports + resume preview
   ═══════════════════════════════════════════════ */

const css = `
  .result {
    max-width: 720px; margin: 0 auto;
    padding: 16px; min-height: calc(100vh - 52px);
  }
  .result-header {
    text-align: center; padding: 24px 0 16px;
  }
  .result-grade {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 6px 16px; border-radius: 999px;
    font-size: 14px; font-weight: 600;
    margin-bottom: 8px;
  }
  .grade-a { background: #E8F9ED; color: #34C759; }
  .grade-b { background: #E8F9ED; color: #34C759; }
  .grade-c { background: #FFF3E0; color: #FF9500; }
  .grade-d { background: #FFE5E3; color: #FF3B30; }
  .result-title {
    font-size: 24px; font-weight: 700;
    color: #1C1C1E; letter-spacing: -0.5px;
  }
  .result-sub {
    font-size: 14px; color: #8E8E93;
    margin-top: 4px;
  }

  /* Tabs */
  .result-tabs {
    display: flex; background: #F2F2F7;
    border-radius: 12px; padding: 2px;
    margin: 16px 0; gap: 2px;
    overflow-x: auto;
  }
  .result-tab {
    flex: 1; min-width: 0;
    padding: 8px 12px; border-radius: 10px;
    font-size: 13px; font-weight: 500;
    text-align: center; color: #8E8E93;
    background: transparent; border: none;
    cursor: pointer; white-space: nowrap;
    transition: all 0.25s;
  }
  .result-tab.active {
    background: #fff; color: #1C1C1E;
    box-shadow: 0 1px 3px rgba(0,0,0,0.06);
    font-weight: 600;
  }

  /* Report card */
  .report-card {
    background: #fff; border-radius: 16px;
    padding: 20px; margin-bottom: 14px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.04);
  }
  .report-content {
    font-size: 14px; color: #3C3C43;
    line-height: 1.8; white-space: pre-wrap;
  }

  /* Resume preview */
  .resume-preview {
    background: #fff; border-radius: 16px;
    padding: 32px 28px; margin-bottom: 14px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.06);
    font-size: 14px; color: #1C1C1E;
    line-height: 1.7;
  }
  .resume-preview h2 {
    font-size: 13px; font-weight: 600;
    color: #fff; background: #00B8A9;
    display: inline-block;
    padding: 3px 14px; border-radius: 999px;
    margin: 18px 0 10px;
  }
  .resume-preview h2:first-child { margin-top: 0; }

  /* Actions */
  .result-actions {
    display: flex; gap: 10px;
    margin: 16px 0; flex-wrap: wrap;
  }
  .result-actions button {
    flex: 1; min-width: 140px;
    padding: 14px; border-radius: 999px;
    font-size: 15px; font-weight: 600;
    border: none; cursor: pointer;
    transition: all 0.2s;
  }
  .btn-download {
    background: #007AFF; color: #fff;
    box-shadow: 0 4px 14px rgba(0,122,255,0.25);
  }
  .btn-download:active { transform: scale(0.97); }
  .btn-copy {
    background: #F2F2F7; color: #1C1C1E;
  }
  .btn-copy:active { background: #E5E5EA; }
  .btn-back {
    background: #F2F2F7; color: #1C1C1E;
  }

  @media (max-width: 390px) {
    .resume-preview { padding: 20px 16px; }
    .result-tab { font-size: 12px; padding: 6px 8px; }
  }
`

const TABS = [
  { id: 'resume', label: '📄 优化简历' },
  { id: 'analyzer', label: '🔍 分析' },
  { id: 'matcher', label: '🎯 匹配' },
  { id: 'optimizer', label: '✍️ 重写' },
  { id: 'polisher', label: '💎 润色' },
  { id: 'coach', label: '🎓 教练' },
  { id: 'verifier', label: '✅ 审核' },
]

function formatResume(text) {
  if (!text) return ''
  // Clean markdown symbols
  let clean = text
    .replace(/#{1,6}\s*/g, '')
    .replace(/\*{1,3}([^*]+)\*{1,3}/g, '$1')
    .replace(/---+/g, '')
    .replace(/```[\s\S]*?```/g, '')
    .replace(/`([^`]+)`/g, '$1')

  // Convert 【title】 to capsule headers
  clean = clean.replace(/【([^】]+)】/g, '<h2>$1</h2>')

  // Convert · bullet points
  clean = clean.replace(/^[·•]\s*/gm, '▸ ')

  return clean
}

function extractGrade(results) {
  const vr = results?.verifier || ''
  const match = vr.match(/评级[：:]\s*([A-D])/i) || vr.match(/([A-D])\s*级/i)
  return match ? match[1].toUpperCase() : 'B'
}

export default function ResultPage() {
  const navigate = useNavigate()
  const [tab, setTab] = useState('resume')
  const [results, setResults] = useState({})
  const resumeRef = useRef(null)

  useEffect(() => {
    const stored = sessionStorage.getItem('rf_results')
    if (stored) {
      setResults(JSON.parse(stored))
    } else {
      navigate('/workspace')
    }
  }, [])

  const grade = extractGrade(results)
  const gradeClass = grade === 'A' || grade === 'B' ? 'grade-a' : grade === 'C' ? 'grade-c' : 'grade-d'
  const gradeMsg = {
    A: '🎉 优秀！建议直接投递',
    B: '👍 良好，可以投递',
    C: '⚠️ 建议修改后再投递',
    D: '❌ 需要大幅修改',
  }

  const finalResume = results.polisher || results.optimizer || ''

  const downloadResume = () => {
    const html = `<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><title>简历</title><style>
      body{font-family:-apple-system,'Noto Sans SC',sans-serif;max-width:800px;margin:40px auto;padding:20px;color:#1a1a1a;line-height:1.7;font-size:14px}
      h2{font-size:13px;font-weight:600;color:#fff;background:#00B8A9;display:inline-block;padding:3px 14px;border-radius:999px;margin:18px 0 10px}
      @media print{body{margin:20px}}
    </style></head><body>${formatResume(finalResume)}</body></html>`
    const blob = new Blob([html], { type: 'text/html' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = '优化简历.html'; a.click()
    URL.revokeObjectURL(url)
  }

  const copyAll = () => {
    const text = Object.entries(results)
      .map(([k, v]) => `═══ ${k} ═══\n${v}`)
      .join('\n\n')
    navigator.clipboard?.writeText(text)
  }

  return (
    <div className="result">
      <style>{css}</style>

      <div className="result-header">
        <div className={`result-grade ${gradeClass}`}>
          {grade} 级 · {gradeMsg[grade]}
        </div>
        <h1 className="result-title">优化完成</h1>
        <p className="result-sub">6个AI已完成全部分析，查看详细报告</p>
      </div>

      {/* Tabs */}
      <div className="result-tabs">
        {TABS.map(t => (
          <button
            key={t.id}
            className={`result-tab ${tab === t.id ? 'active' : ''}`}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Content */}
      {tab === 'resume' ? (
        <>
          <div
            className="resume-preview"
            ref={resumeRef}
            dangerouslySetInnerHTML={{ __html: formatResume(finalResume) }}
          />
          <div className="result-actions">
            <button className="btn-download" onClick={downloadResume}>
              📥 下载简历
            </button>
            <button className="btn-copy" onClick={copyAll}>
              📋 复制全部报告
            </button>
          </div>
        </>
      ) : (
        <div className="report-card">
          <div className="report-content">
            {results[tab] || '暂无数据'}
          </div>
        </div>
      )}

      <button
        className="btn-back"
        style={{
          width: '100%', padding: 14, borderRadius: 999,
          background: '#F2F2F7', color: '#1C1C1E',
          fontSize: 15, fontWeight: 600, border: 'none',
          cursor: 'pointer', marginTop: 8,
        }}
        onClick={() => navigate('/workspace')}
      >
        ← 返回重新优化
      </button>
    </div>
  )
}
