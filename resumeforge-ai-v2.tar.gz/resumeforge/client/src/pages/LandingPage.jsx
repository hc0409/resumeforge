import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../App'

/* ═══════════════════════════════════════════════
   Landing Page — 求职心理引导 + 转化
   iOS white aesthetic, Apple-grade
   ═══════════════════════════════════════════════ */

const css = `
  .landing { min-height: 100vh; background: #fff; }

  /* ── Hero ── */
  .hero {
    min-height: 100vh; min-height: 100dvh;
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    padding: 60px 24px;
    text-align: center;
    position: relative;
    overflow: hidden;
  }
  .hero::before {
    content: '';
    position: absolute; inset: 0;
    background: radial-gradient(ellipse at 50% 0%, rgba(0,122,255,0.06) 0%, transparent 70%);
    pointer-events: none;
  }
  .hero-badge {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 6px 14px; border-radius: 999px;
    background: #F2F2F7; font-size: 13px;
    color: #8E8E93; font-weight: 500;
    margin-bottom: 24px;
    animation: fadeSlideUp 0.5s ease both;
  }
  .hero-badge span { color: #007AFF; font-weight: 600; }
  .hero-title {
    font-size: clamp(32px, 7vw, 52px);
    font-weight: 700; letter-spacing: -1.5px;
    line-height: 1.15; color: #1C1C1E;
    max-width: 600px;
    animation: fadeSlideUp 0.6s ease 0.1s both;
  }
  .hero-title em {
    font-style: normal;
    background: linear-gradient(135deg, #007AFF, #5856D6);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }
  .hero-sub {
    font-size: 17px; color: #8E8E93;
    max-width: 440px; margin-top: 16px;
    line-height: 1.6; font-weight: 400;
    animation: fadeSlideUp 0.6s ease 0.2s both;
  }
  .hero-cta {
    display: flex; gap: 12px; margin-top: 36px;
    animation: fadeSlideUp 0.6s ease 0.3s both;
    flex-wrap: wrap; justify-content: center;
  }
  .cta-main {
    padding: 14px 36px; border-radius: 999px;
    background: #007AFF; color: #fff;
    font-size: 17px; font-weight: 600;
    border: none; cursor: pointer;
    box-shadow: 0 4px 14px rgba(0,122,255,0.3);
    transition: all 0.2s;
  }
  .cta-main:active { transform: scale(0.97); }
  .cta-sec {
    padding: 14px 28px; border-radius: 999px;
    background: #F2F2F7; color: #1C1C1E;
    font-size: 17px; font-weight: 600;
    border: none; cursor: pointer;
    transition: all 0.2s;
  }
  .cta-sec:active { background: #E5E5EA; }
  .hero-price {
    margin-top: 16px; font-size: 14px; color: #AEAEB2;
    animation: fadeSlideUp 0.6s ease 0.35s both;
  }
  .hero-price b { color: #FF9500; font-weight: 600; }

  /* ── Psychology Section ── */
  .psych {
    padding: 80px 24px;
    background: #F2F2F7;
  }
  .psych-inner {
    max-width: 800px; margin: 0 auto;
  }
  .psych-title {
    font-size: 28px; font-weight: 700;
    text-align: center; margin-bottom: 12px;
    letter-spacing: -0.5px;
  }
  .psych-sub {
    font-size: 15px; color: #8E8E93;
    text-align: center; margin-bottom: 48px;
  }
  .psych-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 16px;
  }
  .psych-card {
    background: #fff; border-radius: 16px;
    padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.04);
    transition: transform 0.3s;
  }
  .psych-card:hover { transform: translateY(-2px); }
  .psych-icon {
    width: 48px; height: 48px;
    border-radius: 12px; display: flex;
    align-items: center; justify-content: center;
    font-size: 24px; margin-bottom: 14px;
  }
  .psych-card h3 {
    font-size: 16px; font-weight: 600;
    margin-bottom: 8px; color: #1C1C1E;
  }
  .psych-card p {
    font-size: 14px; color: #8E8E93;
    line-height: 1.6;
  }

  /* ── Pipeline Demo ── */
  .pipeline-sec {
    padding: 80px 24px;
    background: #fff;
  }
  .pipeline-inner {
    max-width: 700px; margin: 0 auto; text-align: center;
  }
  .pipeline-title {
    font-size: 28px; font-weight: 700;
    margin-bottom: 12px; letter-spacing: -0.5px;
  }
  .pipeline-sub {
    font-size: 15px; color: #8E8E93;
    margin-bottom: 40px;
  }
  .pipeline-steps {
    display: flex; align-items: center;
    justify-content: center; gap: 0;
    flex-wrap: wrap; padding: 20px 0;
  }
  .p-step {
    display: flex; flex-direction: column;
    align-items: center; gap: 8px;
  }
  .p-node {
    width: 52px; height: 52px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 22px; background: #F2F2F7;
    transition: all 0.5s;
  }
  .p-node.lit {
    background: linear-gradient(135deg, #007AFF, #5856D6);
    box-shadow: 0 4px 14px rgba(0,122,255,0.3);
  }
  .p-label {
    font-size: 11px; color: #8E8E93;
    font-weight: 500; white-space: nowrap;
  }
  .p-line {
    width: 28px; height: 2px;
    background: #E5E5EA; margin: 0 4px;
    margin-bottom: 22px;
    transition: background 0.5s;
  }
  .p-line.lit { background: #007AFF; }

  /* ── Pricing ── */
  .pricing {
    padding: 80px 24px;
    background: #F2F2F7;
    text-align: center;
  }
  .pricing-title {
    font-size: 28px; font-weight: 700;
    margin-bottom: 12px; letter-spacing: -0.5px;
  }
  .pricing-sub {
    font-size: 15px; color: #8E8E93;
    margin-bottom: 40px;
  }
  .price-cards {
    display: flex; gap: 16px;
    justify-content: center; flex-wrap: wrap;
    max-width: 700px; margin: 0 auto;
  }
  .price-card {
    background: #fff; border-radius: 20px;
    padding: 32px 28px; min-width: 260px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.04);
    position: relative; overflow: hidden;
    flex: 1; max-width: 320px;
  }
  .price-card.featured {
    border: 2px solid #007AFF;
    box-shadow: 0 8px 30px rgba(0,122,255,0.12);
  }
  .price-card.featured::before {
    content: '推荐';
    position: absolute; top: 12px; right: -24px;
    background: #007AFF; color: #fff;
    font-size: 11px; font-weight: 600;
    padding: 3px 32px;
    transform: rotate(45deg);
  }
  .price-name {
    font-size: 18px; font-weight: 600;
    color: #1C1C1E; margin-bottom: 8px;
  }
  .price-amount {
    font-size: 44px; font-weight: 700;
    color: #007AFF; letter-spacing: -2px;
  }
  .price-amount small {
    font-size: 16px; font-weight: 500;
    color: #8E8E93;
  }
  .price-unit {
    font-size: 13px; color: #AEAEB2;
    margin-top: 4px; margin-bottom: 20px;
  }
  .price-features {
    text-align: left; margin-bottom: 24px;
  }
  .price-feat {
    display: flex; align-items: center; gap: 8px;
    font-size: 14px; color: #3C3C43;
    padding: 6px 0;
  }
  .price-feat::before {
    content: '✓'; color: #34C759;
    font-weight: 700; font-size: 14px;
  }
  .price-btn {
    width: 100%; padding: 12px;
    border-radius: 999px; font-size: 15px;
    font-weight: 600; border: none; cursor: pointer;
    transition: all 0.2s;
  }
  .price-btn.primary {
    background: #007AFF; color: #fff;
    box-shadow: 0 4px 14px rgba(0,122,255,0.25);
  }
  .price-btn.secondary {
    background: #F2F2F7; color: #1C1C1E;
  }

  /* ── Footer ── */
  .landing-footer {
    padding: 40px 24px;
    background: #fff;
    text-align: center;
    border-top: 0.5px solid rgba(0,0,0,0.06);
  }
  .footer-text {
    font-size: 13px; color: #AEAEB2; line-height: 2;
  }
  .footer-text a {
    color: #007AFF; text-decoration: none;
  }

  /* ── Scroll anim ── */
  .reveal {
    opacity: 0; transform: translateY(24px);
    transition: all 0.7s cubic-bezier(0.25,0.46,0.45,0.94);
  }
  .reveal.visible {
    opacity: 1; transform: translateY(0);
  }

  @keyframes fadeSlideUp {
    from { opacity: 0; transform: translateY(16px); }
    to { opacity: 1; transform: translateY(0); }
  }
`

const PSYCH_CARDS = [
  { icon: '😰', bg: '#FFF3E0', title: '投了50份没回复？', desc: '90%的简历在ATS系统就被过滤。不是你不够好，是简历没对上关键词。' },
  { icon: '🤯', bg: '#E8F7FE', title: '不知道怎么写经历？', desc: '三无选手（无经验/无项目/无亮点）也能包装。STAR法则+量化，HR最爱。' },
  { icon: '💪', bg: '#E8F9ED', title: '面试总被压价？', desc: '69.9元面试辅导，含谈薪剧本+高情商回答模板+逆向提问法，拿到满意offer。' },
  { icon: '🎯', bg: '#F3E8FA', title: '简历石沉大海？', desc: '6个AI同时优化，STAR强化+老社畜写法+HR视角审核，通过率提升3倍。' },
]

const PIPELINE_STEPS = [
  { icon: '🔍', label: '深度分析' },
  { icon: '🎯', label: 'JD匹配' },
  { icon: '✍️', label: 'STAR重写' },
  { icon: '💎', label: '润色包装' },
  { icon: '✅', label: '终审评分' },
]

export default function LandingPage() {
  const { user, setShowLogin } = useApp()
  const navigate = useNavigate()
  const [litIndex, setLitIndex] = useState(-1)

  // Pipeline animation
  useEffect(() => {
    const timer = setInterval(() => {
      setLitIndex(prev => prev >= PIPELINE_STEPS.length - 1 ? -1 : prev + 1)
    }, 800)
    return () => clearInterval(timer)
  }, [])

  // Scroll reveal
  useEffect(() => {
    const els = document.querySelectorAll('.reveal')
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          e.target.classList.add('visible')
          obs.unobserve(e.target)
        }
      })
    }, { threshold: 0.15 })
    els.forEach(el => obs.observe(el))
    return () => obs.disconnect()
  }, [])

  const handleStart = () => {
    if (!user) {
      setShowLogin(true)
    } else {
      navigate('/workspace')
    }
  }

  return (
    <div className="landing">
      <style>{css}</style>

      {/* ── Hero ── */}
      <section className="hero">
        <div className="hero-badge">
          🤖 <span>6大AI协同</span> · 全自动流水线
        </div>
        <h1 className="hero-title">
          让简历<em>自己会说话</em>
        </h1>
        <p className="hero-sub">
          6个顶级AI模型全自动分析、重写、润色你的简历，
          从HR视角出发，让每一份投递都值得一个面试机会。
        </p>
        <div className="hero-cta">
          <button className="cta-main" onClick={handleStart}>
            开始优化简历
          </button>
          <button className="cta-sec" onClick={() => navigate('/interview')}>
            面试辅导
          </button>
        </div>
        <p className="hero-price">
          简历优化 <b>¥1.99</b>/次 · 面试辅导 <b>¥69.9</b>/次 · 扫码支付即用
        </p>
      </section>

      {/* ── Psychology ── */}
      <section className="psych reveal">
        <div className="psych-inner">
          <h2 className="psych-title">你是不是也遇到了这些问题？</h2>
          <p className="psych-sub">别焦虑，我们见过太多类似的情况，每一个都能解决</p>
          <div className="psych-cards">
            {PSYCH_CARDS.map((c, i) => (
              <div className="psych-card" key={i}>
                <div className="psych-icon" style={{ background: c.bg }}>{c.icon}</div>
                <h3>{c.title}</h3>
                <p>{c.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Pipeline Demo ── */}
      <section className="pipeline-sec reveal">
        <div className="pipeline-inner">
          <h2 className="pipeline-title">全自动AI流水线</h2>
          <p className="pipeline-sub">
            DeepSeek-V3.2 · Kimi-K2.5 · Qwen3.5 · GLM-5.1 · MiniMax-M2.5<br/>
            5个顶级模型各司其职，120秒出结果
          </p>
          <div className="pipeline-steps">
            {PIPELINE_STEPS.map((step, i) => (
              <React.Fragment key={i}>
                <div className="p-step">
                  <div className={`p-node ${i <= litIndex ? 'lit' : ''}`}>
                    {step.icon}
                  </div>
                  <span className="p-label">{step.label}</span>
                </div>
                {i < PIPELINE_STEPS.length - 1 && (
                  <div className={`p-line ${i < litIndex ? 'lit' : ''}`} />
                )}
              </React.Fragment>
            ))}
          </div>
        </div>
      </section>

      {/* ── Pricing ── */}
      <section className="pricing reveal">
        <h2 className="pricing-title">简单透明的定价</h2>
        <p className="pricing-sub">不订阅、不绑定，用多少付多少</p>
        <div className="price-cards">
          <div className="price-card featured">
            <div className="price-name">简历优化</div>
            <div className="price-amount">¥1.99<small>/次</small></div>
            <div className="price-unit">约一杯奶茶的价格</div>
            <div className="price-features">
              <div className="price-feat">6大AI全自动分析重写</div>
              <div className="price-feat">STAR法则 + 量化包装</div>
              <div className="price-feat">HR视角终审评分</div>
              <div className="price-feat">可下载HTML精美简历</div>
              <div className="price-feat">三无策略智能包装</div>
            </div>
            <button className="price-btn primary" onClick={handleStart}>
              立即使用
            </button>
          </div>
          <div className="price-card">
            <div className="price-name">面试辅导</div>
            <div className="price-amount">¥69.9<small>/次</small></div>
            <div className="price-unit">根据你的简历定制</div>
            <div className="price-features">
              <div className="price-feat">多AI协作深度辅导</div>
              <div className="price-feat">谈薪剧本 + 压价应对</div>
              <div className="price-feat">逆向思维提问法</div>
              <div className="price-feat">高情商回答模板</div>
              <div className="price-feat">14天冲刺计划</div>
            </div>
            <button className="price-btn secondary" onClick={() => navigate('/interview')}>
              了解更多
            </button>
          </div>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer className="landing-footer">
        <p className="footer-text">
          ResumeForge AI — 让每一份简历都值得一个面试机会<br/>
          问题反馈: <a href="https://wpa.qq.com/msgrd?v=3&uin=2740035240" target="_blank" rel="noopener">QQ 2740035240</a><br/>
          © 2026 ResumeForge · 用心做好一件事
        </p>
      </footer>
    </div>
  )
}
