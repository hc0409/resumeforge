import React, { useState, useEffect, createContext, useContext } from 'react'
import { BrowserRouter, Routes, Route, useNavigate, useLocation } from 'react-router-dom'
import LandingPage from './pages/LandingPage'
import WorkspacePage from './pages/WorkspacePage'
import ResultPage from './pages/ResultPage'
import InterviewPage from './pages/InterviewPage'
import PaymentSheet from './components/PaymentSheet'
import LoginSheet from './components/LoginSheet'
import Header from './components/Header'
import { api } from './utils/api'

// ── Global Context ──
export const AppContext = createContext(null)

export function useApp() {
  return useContext(AppContext)
}

function AppInner() {
  const [user, setUser] = useState(null)
  const [credits, setCredits] = useState(0)
  const [showLogin, setShowLogin] = useState(false)
  const [showPayment, setShowPayment] = useState(false)
  const [payType, setPayType] = useState('resume') // resume | interview
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()
  const location = useLocation()

  // Check auth on mount
  useEffect(() => {
    const token = localStorage.getItem('rf_token')
    if (token) {
      api.getMe()
        .then(data => {
          setUser(data.user)
          setCredits(data.user.credits)
        })
        .catch(() => {
          localStorage.removeItem('rf_token')
        })
        .finally(() => setLoading(false))
    } else {
      setLoading(false)
    }
  }, [])

  const openPayment = (type = 'resume') => {
    setPayType(type)
    setShowPayment(true)
  }

  const handleLogin = (userData, token) => {
    localStorage.setItem('rf_token', token)
    setUser(userData)
    setCredits(userData.credits)
    setShowLogin(false)
  }

  const handleLogout = () => {
    localStorage.removeItem('rf_token')
    setUser(null)
    setCredits(0)
    navigate('/')
  }

  const refreshCredits = async () => {
    try {
      const data = await api.getMe()
      setCredits(data.user.credits)
    } catch {}
  }

  const ctx = {
    user, setUser, credits, setCredits,
    showLogin, setShowLogin,
    showPayment, setShowPayment,
    payType, openPayment,
    handleLogin, handleLogout, refreshCredits,
    loading,
  }

  const isLanding = location.pathname === '/'

  return (
    <AppContext.Provider value={ctx}>
      {!isLanding && <Header />}
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/workspace" element={<WorkspacePage />} />
        <Route path="/result" element={<ResultPage />} />
        <Route path="/interview" element={<InterviewPage />} />
      </Routes>
      {showLogin && <LoginSheet />}
      {showPayment && <PaymentSheet type={payType} />}
    </AppContext.Provider>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AppInner />
    </BrowserRouter>
  )
}
