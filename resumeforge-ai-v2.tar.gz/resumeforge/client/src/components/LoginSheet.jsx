import React, { useState } from 'react'
import { useApp } from '../App'
import { api } from '../utils/api'

const s = {
  overlay: {
    position: 'fixed', inset: 0,
    background: 'rgba(0,0,0,0.4)',
    zIndex: 1000, display: 'flex',
    alignItems: 'flex-end', justifyContent: 'center',
    animation: 'fadeIn 0.2s ease',
  },
  sheet: {
    background: '#fff',
    borderRadius: '20px 20px 0 0',
    width: '100%', maxWidth: 420,
    padding: '20px 24px 40px',
    animation: 'slideUp 0.35s cubic-bezier(0.34,1.56,0.64,1)',
  },
  handle: {
    width: 36, height: 5,
    background: '#E5E5EA', borderRadius: 3,
    margin: '0 auto 20px',
  },
  title: {
    fontSize: 22, fontWeight: 700,
    textAlign: 'center', marginBottom: 6,
    color: '#1C1C1E',
  },
  sub: {
    fontSize: 14, color: '#8E8E93',
    textAlign: 'center', marginBottom: 28,
  },
  inputGroup: {
    display: 'flex', gap: 10, marginBottom: 14,
  },
  input: {
    flex: 1, padding: '14px 16px',
    background: '#F2F2F7', borderRadius: 12,
    border: '1.5px solid transparent',
    fontSize: 15, color: '#1C1C1E',
    outline: 'none', transition: 'all 0.2s',
  },
  codeBtn: {
    padding: '14px 16px', borderRadius: 12,
    background: '#007AFF', color: '#fff',
    fontSize: 14, fontWeight: 600,
    border: 'none', cursor: 'pointer',
    whiteSpace: 'nowrap', flexShrink: 0,
    transition: 'opacity 0.2s',
  },
  submitBtn: {
    width: '100%', padding: '15px',
    borderRadius: 999, background: '#007AFF',
    color: '#fff', fontSize: 16, fontWeight: 600,
    border: 'none', cursor: 'pointer',
    marginTop: 8,
    boxShadow: '0 4px 14px rgba(0,122,255,0.25)',
    transition: 'all 0.2s',
  },
  divider: {
    display: 'flex', alignItems: 'center',
    gap: 12, margin: '24px 0',
  },
  divLine: {
    flex: 1, height: 0.5,
    background: '#E5E5EA',
  },
  divText: {
    fontSize: 13, color: '#AEAEB2',
  },
  guestBtn: {
    width: '100%', padding: '14px',
    borderRadius: 999, background: '#F2F2F7',
    color: '#1C1C1E', fontSize: 15, fontWeight: 600,
    border: 'none', cursor: 'pointer',
    transition: 'background 0.2s',
  },
  error: {
    fontSize: 13, color: '#FF3B30',
    textAlign: 'center', marginTop: 8,
  },
}

export default function LoginSheet() {
  const { setShowLogin, handleLogin } = useApp()
  const [phone, setPhone] = useState('')
  const [code, setCode] = useState('')
  const [codeSent, setCodeSent] = useState(false)
  const [countdown, setCountdown] = useState(0)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const sendCode = async () => {
    if (phone.length !== 11) {
      setError('请输入11位手机号')
      return
    }
    try {
      await api.sendCode(phone)
      setCodeSent(true)
      setError('')
      let t = 60
      setCountdown(t)
      const timer = setInterval(() => {
        t--
        setCountdown(t)
        if (t <= 0) clearInterval(timer)
      }, 1000)
    } catch (e) {
      setError(e.message)
    }
  }

  const submitLogin = async () => {
    if (!phone || !code) {
      setError('请输入手机号和验证码')
      return
    }
    setLoading(true)
    try {
      const data = await api.login(phone, code)
      handleLogin(data.user, data.token)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  const guestStart = async () => {
    setLoading(true)
    try {
      const data = await api.guestLogin()
      handleLogin(data.user, data.token)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={s.overlay} onClick={(e) => e.target === e.currentTarget && setShowLogin(false)}>
      <div style={s.sheet}>
        <div style={s.handle} />
        <div style={s.title}>登录 ResumeForge</div>
        <div style={s.sub}>登录后自动赠送 1 次免费体验</div>

        <div style={s.inputGroup}>
          <input
            style={s.input}
            type="tel"
            placeholder="手机号"
            value={phone}
            onChange={e => setPhone(e.target.value.replace(/\D/g, '').slice(0, 11))}
            onFocus={e => {
              e.target.style.borderColor = '#007AFF'
              e.target.style.background = '#fff'
            }}
            onBlur={e => {
              e.target.style.borderColor = 'transparent'
              e.target.style.background = '#F2F2F7'
            }}
          />
          <button
            style={{ ...s.codeBtn, opacity: countdown > 0 ? 0.5 : 1 }}
            onClick={sendCode}
            disabled={countdown > 0}
          >
            {countdown > 0 ? `${countdown}s` : '获取验证码'}
          </button>
        </div>

        <input
          style={{ ...s.input, width: '100%', marginBottom: 8 }}
          type="text"
          placeholder="验证码"
          value={code}
          onChange={e => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
        />

        <button
          style={{ ...s.submitBtn, opacity: loading ? 0.6 : 1 }}
          onClick={submitLogin}
          disabled={loading}
        >
          {loading ? '登录中...' : '登录'}
        </button>

        {error && <div style={s.error}>{error}</div>}

        <div style={s.divider}>
          <div style={s.divLine} />
          <span style={s.divText}>或</span>
          <div style={s.divLine} />
        </div>

        <button
          style={s.guestBtn}
          onClick={guestStart}
          disabled={loading}
        >
          游客体验（赠送1次）
        </button>
      </div>
    </div>
  )
}
