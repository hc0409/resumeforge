import React, { useState } from 'react'
import { useApp } from '../App'

const s = {
  overlay: {
    position: 'fixed', inset: 0,
    background: 'rgba(0,0,0,0.4)',
    zIndex: 1000, display: 'flex',
    alignItems: 'flex-end', justifyContent: 'center',
    animation: 'fadeIn 0.2s ease',
  },
  sheet: {
    background: '#fff',
    borderRadius: '20px 20px 0 0',
    width: '100%', maxWidth: 420,
    padding: '20px 24px 40px',
    animation: 'slideUp 0.35s cubic-bezier(0.34,1.56,0.64,1)',
  },
  handle: {
    width: 36, height: 5,
    background: '#E5E5EA', borderRadius: 3,
    margin: '0 auto 20px',
  },
  title: {
    fontSize: 22, fontWeight: 700,
    textAlign: 'center', marginBottom: 6,
    color: '#1C1C1E',
  },
  sub: {
    fontSize: 14, color: '#8E8E93',
    textAlign: 'center', marginBottom: 24,
  },
  priceBox: {
    textAlign: 'center', padding: '24px 0',
    background: '#F2F2F7', borderRadius: 16,
    marginBottom: 20,
  },
  priceLabel: {
    fontSize: 14, color: '#8E8E93',
    marginBottom: 4,
  },
  priceValue: {
    fontSize: 48, fontWeight: 700,
    color: '#FF9500', letterSpacing: -2,
  },
  priceUnit: {
    fontSize: 16, fontWeight: 500,
    color: '#AEAEB2',
  },
  steps: {
    marginBottom: 24,
  },
  step: {
    display: 'flex', alignItems: 'flex-start',
    gap: 12, padding: '10px 0',
  },
  stepNum: {
    width: 24, height: 24,
    borderRadius: '50%', background: '#007AFF',
    color: '#fff', fontSize: 12, fontWeight: 700,
    display: 'flex', alignItems: 'center',
    justifyContent: 'center', flexShrink: 0,
  },
  stepText: {
    fontSize: 14, color: '#3C3C43',
    lineHeight: 1.5,
  },
  stepLink: {
    color: '#007AFF', fontWeight: 600,
    textDecoration: 'none',
  },
  qrPlaceholder: {
    width: 180, height: 180,
    margin: '0 auto 16px',
    background: '#F2F2F7', borderRadius: 16,
    display: 'flex', alignItems: 'center',
    justifyContent: 'center', flexDirection: 'column',
    gap: 8,
  },
  qrIcon: {
    fontSize: 48,
  },
  qrText: {
    fontSize: 13, color: '#8E8E93',
  },
  confirmBtn: {
    width: '100%', padding: '15px',
    borderRadius: 999, background: '#34C759',
    color: '#fff', fontSize: 16, fontWeight: 600,
    border: 'none', cursor: 'pointer',
    boxShadow: '0 4px 14px rgba(52,199,89,0.25)',
    marginTop: 16,
  },
  note: {
    fontSize: 12, color: '#AEAEB2',
    textAlign: 'center', marginTop: 12,
    lineHeight: 1.5,
  },
}

const PRICES = {
  resume: { name: '简历优化', price: '1.99', desc: '6大AI全自动优化一次' },
  interview: { name: '面试辅导', price: '69.9', desc: '多AI协作深度辅导一次' },
}

export default function PaymentSheet({ type = 'resume' }) {
  const { setShowPayment, refreshCredits } = useApp()
  const info = PRICES[type]
  const [confirming, setConfirming] = useState(false)

  const handleConfirm = async () => {
    setConfirming(true)
    try {
      // Check with backend if payment is received
      // For scan-to-pay, user needs to contact QQ after paying
      await refreshCredits()
      setShowPayment(false)
    } catch {
      // Just close
      setShowPayment(false)
    }
  }

  return (
    <div style={s.overlay} onClick={(e) => e.target === e.currentTarget && setShowPayment(false)}>
      <div style={s.sheet}>
        <div style={s.handle} />
        <div style={s.title}>{info.name}</div>
        <div style={s.sub}>{info.desc}</div>

        <div style={s.priceBox}>
          <div style={s.priceLabel}>支付金额</div>
          <div>
            <span style={s.priceValue}>¥{info.price}</span>
            <span style={s.priceUnit}>/次</span>
          </div>
        </div>

        <div style={s.steps}>
          <div style={s.step}>
            <div style={s.stepNum}>1</div>
            <div style={s.stepText}>
              打开微信，扫描下方收款码，转账 <b>¥{info.price}</b>
            </div>
          </div>
          <div style={s.step}>
            <div style={s.stepNum}>2</div>
            <div style={s.stepText}>
              转账备注写上你的 <b>手机号</b>
            </div>
          </div>
          <div style={s.step}>
            <div style={s.stepNum}>3</div>
            <div style={s.stepText}>
              转账后联系 <a style={s.stepLink} href="https://wpa.qq.com/msgrd?v=3&uin=2740035240" target="_blank" rel="noopener">
                QQ: 2740035240
              </a> 发送截图，秒充次数
            </div>
          </div>
        </div>

        <div style={s.qrPlaceholder}>
          <div style={s.qrIcon}>💚</div>
          <div style={s.qrText}>微信收款码</div>
          <div style={{ fontSize: 11, color: '#AEAEB2' }}>管理员设置后显示</div>
        </div>

        <button style={s.confirmBtn} onClick={handleConfirm}>
          {confirming ? '确认中...' : '我已完成转账'}
        </button>

        <div style={s.note}>
          支付遇到问题？联系 QQ 2740035240<br/>
          未来将接入微信自动支付
        </div>
      </div>
    </div>
  )
}
