import React from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../App'

const s = {
  header: {
    position: 'sticky',
    top: 0,
    zIndex: 100,
    background: 'rgba(255,255,255,0.72)',
    backdropFilter: 'saturate(180%) blur(20px)',
    WebkitBackdropFilter: 'saturate(180%) blur(20px)',
    borderBottom: '0.5px solid rgba(0,0,0,0.08)',
    padding: '0 16px',
    height: 52,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  logo: {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    cursor: 'pointer',
  },
  logoIcon: {
    width: 30,
    height: 30,
    borderRadius: 8,
    background: 'linear-gradient(135deg, #007AFF, #5856D6)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#fff',
    fontSize: 14,
    fontWeight: 700,
  },
  logoText: {
    fontSize: 17,
    fontWeight: 600,
    color: '#1C1C1E',
    letterSpacing: '-0.3px',
  },
  right: {
    display: 'flex',
    alignItems: 'center',
    gap: 10,
  },
  credits: {
    display: 'flex',
    alignItems: 'center',
    gap: 4,
    padding: '6px 12px',
    borderRadius: 999,
    background: '#F2F2F7',
    fontSize: 13,
    fontWeight: 600,
    color: '#3C3C43',
    cursor: 'pointer',
    transition: 'background 0.2s',
  },
  avatar: {
    width: 32,
    height: 32,
    borderRadius: '50%',
    background: 'linear-gradient(135deg, #007AFF, #AF52DE)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#fff',
    fontSize: 13,
    fontWeight: 600,
    cursor: 'pointer',
  },
  loginBtn: {
    padding: '6px 16px',
    borderRadius: 999,
    background: '#007AFF',
    color: '#fff',
    fontSize: 14,
    fontWeight: 600,
    border: 'none',
    cursor: 'pointer',
  },
}

export default function Header() {
  const { user, credits, setShowLogin, openPayment } = useApp()
  const navigate = useNavigate()

  return (
    <header style={s.header}>
      <div style={s.logo} onClick={() => navigate('/')}>
        <div style={s.logoIcon}>RF</div>
        <span style={s.logoText}>ResumeForge</span>
      </div>
      <div style={s.right}>
        {user ? (
          <>
            <div style={s.credits} onClick={() => openPayment('resume')}>
              💎 {credits} 次
            </div>
            <div style={s.avatar}>
              {(user.phone || user.name || 'G').charAt(0).toUpperCase()}
            </div>
          </>
        ) : (
          <button style={s.loginBtn} onClick={() => setShowLogin(true)}>
            登录
          </button>
        )}
      </div>
    </header>
  )
}
