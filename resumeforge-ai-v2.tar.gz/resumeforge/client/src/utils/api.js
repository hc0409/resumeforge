/* ═══ API Helper ═══ */
const BASE = '/api'

async function request(path, options = {}) {
  const token = localStorage.getItem('rf_token')
  const res = await fetch(`${BASE}${path}`, {
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
    ...options,
  })
  const data = await res.json()
  if (!res.ok) throw new Error(data.error || '请求失败')
  return data
}

export const api = {
  // Auth
  login: (phone, code) => request('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ phone, code }),
  }),
  sendCode: (phone) => request('/auth/send-code', {
    method: 'POST',
    body: JSON.stringify({ phone }),
  }),
  guestLogin: () => request('/auth/guest', { method: 'POST' }),
  getMe: () => request('/auth/me'),

  // Resume pipeline
  runPipeline: (resume, jd, fileData) => request('/resume/run', {
    method: 'POST',
    body: JSON.stringify({ resume, jd, fileData }),
  }),
  getPipelineStatus: (taskId) => request(`/resume/status/${taskId}`),

  // Interview coaching
  runInterview: (resume, jd) => request('/interview/run', {
    method: 'POST',
    body: JSON.stringify({ resume, jd }),
  }),

  // Payment
  createOrder: (type) => request('/pay/create', {
    method: 'POST',
    body: JSON.stringify({ type }),
  }),
  checkOrder: (orderId) => request(`/pay/check/${orderId}`),

  // Models
  getModels: () => request('/models'),

  // Admin
  getConfig: () => request('/admin/config'),
  updateConfig: (config) => request('/admin/config', {
    method: 'PUT',
    body: JSON.stringify(config),
  }),
  getStats: () => request('/admin/stats'),
}
