/* ═══ File Parser — supports txt, pdf, docx, images ═══ */

export async function parseFile(file) {
  const name = file.name.toLowerCase()

  // Plain text files
  if (name.endsWith('.txt') || name.endsWith('.md')) {
    return await file.text()
  }

  // For PDF, DOCX, images — convert to base64 and send to backend for extraction
  const base64 = await fileToBase64(file)
  const ext = name.split('.').pop()

  try {
    const res = await fetch('/api/file/parse', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ data: base64, ext, name: file.name }),
    })
    const result = await res.json()
    if (!res.ok) throw new Error(result.error)
    return result.text
  } catch (e) {
    // Fallback: if backend fails, try reading as text
    console.warn('Backend parse failed, trying text fallback:', e)
    return await file.text()
  }
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => {
      const result = reader.result
      // Remove data:xxx;base64, prefix
      const base64 = result.split(',')[1] || result
      resolve(base64)
    }
    reader.onerror = reject
    reader.readAsDataURL(file)
  })
}

export const ACCEPTED_TYPES = '.txt,.md,.pdf,.doc,.docx,.png,.jpg,.jpeg,.webp'

export function getFileIcon(name) {
  const ext = name.split('.').pop().toLowerCase()
  const map = {
    pdf: '📄', doc: '📝', docx: '📝', txt: '📃', md: '📃',
    png: '🖼️', jpg: '🖼️', jpeg: '🖼️', webp: '🖼️',
  }
  return map[ext] || '📎'
}
