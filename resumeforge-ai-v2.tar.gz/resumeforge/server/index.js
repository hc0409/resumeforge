import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

import authRoutes from './routes/auth.js'
import resumeRoutes from './routes/resume.js'
import interviewRoutes from './routes/interview.js'
import payRoutes from './routes/pay.js'
import modelRoutes from './routes/models.js'
import adminRoutes from './routes/admin.js'
import fileRoutes from './routes/file.js'

dotenv.config()

const app = express()
const PORT = process.env.PORT || 3001

const __dirname = dirname(fileURLToPath(import.meta.url))

// Middleware
app.use(cors())
app.use(express.json({ limit: '20mb' }))

// API Routes
app.use('/api/auth', authRoutes)
app.use('/api/resume', resumeRoutes)
app.use('/api/interview', interviewRoutes)
app.use('/api/pay', payRoutes)
app.use('/api/models', modelRoutes)
app.use('/api/admin', adminRoutes)
app.use('/api/file', fileRoutes)

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', version: '2.0.0' })
})

// Serve frontend in production
const clientDist = join(__dirname, '..', 'client', 'dist')
app.use(express.static(clientDist))
app.get('*', (req, res) => {
  res.sendFile(join(clientDist, 'index.html'))
})

app.listen(PORT, () => {
  console.log(`✅ ResumeForge API running on :${PORT}`)
})
