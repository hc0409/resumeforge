import jwt from 'jsonwebtoken'

export function authRequired(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '')
  if (!token) return res.status(401).json({ error: '请先登录' })

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET)
    req.userId = decoded.userId
    next()
  } catch {
    res.status(401).json({ error: '登录已过期，请重新登录' })
  }
}

export function adminRequired(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '')
  if (!token) return res.status(401).json({ error: '请先登录' })

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET)
    req.userId = decoded.userId
    if (!decoded.isAdmin) return res.status(403).json({ error: '权限不足' })
    next()
  } catch {
    res.status(401).json({ error: '登录已过期' })
  }
}

export function generateToken(userId, isAdmin = false) {
  return jwt.sign({ userId, isAdmin }, process.env.JWT_SECRET, { expiresIn: '30d' })
}
