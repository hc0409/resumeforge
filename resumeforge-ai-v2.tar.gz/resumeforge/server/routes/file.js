import { Router } from 'express'
import { callAI, DEFAULT_MODELS } from '../services/ai.js'

const router = Router()

router.post('/parse', async (req, res) => {
  const { data, ext, name } = req.body

  if (!data) {
    return res.status(400).json({ error: '无文件数据' })
  }

  try {
    // For images — use AI vision to extract text
    if (['png', 'jpg', 'jpeg', 'webp'].includes(ext)) {
      const apiKey = process.env.SILICONCLOUD_API_KEY
      const response = await fetch('https://api.siliconflow.cn/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: 'Pro/Qwen/Qwen2.5-VL-72B-Instruct',
          messages: [{
            role: 'user',
            content: [
              {
                type: 'image_url',
                image_url: { url: `data:image/${ext};base64,${data}` },
              },
              {
                type: 'text',
                text: '请完整提取这张图片中的所有文字内容，保持原有格式和排版。如果是简历，请完整输出所有信息。',
              },
            ],
          }],
          max_tokens: 4096,
        }),
      })

      const result = await response.json()
      const text = result.choices?.[0]?.message?.content || ''
      return res.json({ text })
    }

    // For PDF/DOCX — use AI to extract (base64 → text)
    if (['pdf', 'doc', 'docx'].includes(ext)) {
      // SiliconCloud supports document parsing via vision models
      const apiKey = process.env.SILICONCLOUD_API_KEY
      const response = await fetch('https://api.siliconflow.cn/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: 'Pro/Qwen/Qwen2.5-VL-72B-Instruct',
          messages: [{
            role: 'user',
            content: [
              {
                type: 'file',
                file_url: { url: `data:application/${ext === 'pdf' ? 'pdf' : 'vnd.openxmlformats-officedocument.wordprocessingml.document'};base64,${data}` },
              },
              {
                type: 'text',
                text: '请完整提取这份文档中的所有文字内容，保持原有格式。',
              },
            ],
          }],
          max_tokens: 4096,
        }),
      })

      const result = await response.json()
      const text = result.choices?.[0]?.message?.content || ''
      return res.json({ text })
    }

    // Fallback — try to decode as text
    const text = Buffer.from(data, 'base64').toString('utf-8')
    res.json({ text })
  } catch (err) {
    console.error('File parse error:', err)
    res.status(500).json({ error: '文件解析失败: ' + err.message })
  }
})

export default router
