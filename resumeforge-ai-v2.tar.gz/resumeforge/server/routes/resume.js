import { Router } from 'express'
import supabase from '../services/supabase.js'
import { callAI, DEFAULT_MODELS } from '../services/ai.js'
import { authRequired } from '../middleware/auth.js'
import PROMPTS from '../prompts/index.js'

const router = Router()

// ── Run single pipeline step ──
router.post('/run', authRequired, async (req, res) => {
  const { resume, jd, fileData } = req.body
  const { agent, step, previousResults } = fileData || {}

  if (!resume) {
    return res.status(400).json({ error: '请输入简历内容' })
  }

  // Check credits (only deduct on first step)
  if (step === 0) {
    const { data: user } = await supabase
      .from('users')
      .select('credits')
      .eq('id', req.userId)
      .single()

    if (!user || user.credits <= 0) {
      return res.status(402).json({ error: '次数不足，请先充值' })
    }

    // Deduct 1 credit
    await supabase
      .from('users')
      .update({ credits: user.credits - 1 })
      .eq('id', req.userId)
  }

  try {
    const model = DEFAULT_MODELS[agent] || DEFAULT_MODELS.analyzer
    const prompt = PROMPTS[agent] || PROMPTS.analyzer

    // Build user message based on agent type
    let userMsg = ''

    switch (agent) {
      case 'analyzer':
        userMsg = `简历内容:\n${resume}\n\n${jd ? `目标岗位JD:\n${jd}` : '(未提供目标JD)'}`
        break

      case 'matcher':
        userMsg = `简历:\n${resume}\n\n目标JD:\n${jd || '(未提供)'}\n\n分析师报告:\n${previousResults?.analyzer || '(无)'}`
        break

      case 'optimizer':
        userMsg = `原始简历:\n${resume}\n\n目标JD:\n${jd || ''}\n\n分析师报告:\n${previousResults?.analyzer || ''}\n\n匹配分析:\n${previousResults?.matcher || ''}\n\n请根据以上分析，用STAR法则和老社畜写法重写这份简历。`
        break

      case 'polisher':
        userMsg = `请润色以下已优化的简历:\n\n${previousResults?.optimizer || resume}`
        break

      case 'coach':
        userMsg = `简历:\n${previousResults?.polisher || previousResults?.optimizer || resume}\n\n目标JD:\n${jd || '(未提供)'}\n\n请定制面试备考方案。`
        break

      case 'verifier':
        userMsg = `请审核以下简历:\n\n${previousResults?.polisher || previousResults?.optimizer || resume}`
        break

      default:
        userMsg = resume
    }

    const { content, usage } = await callAI(model, prompt, userMsg, {
      maxTokens: agent === 'optimizer' || agent === 'coach' ? 6000 : 4096,
      temperature: agent === 'optimizer' ? 0.8 : 0.7,
    })

    // Log usage
    await supabase.from('usage_logs').insert({
      user_id: req.userId,
      agent,
      model,
      tokens_in: usage.prompt_tokens || 0,
      tokens_out: usage.completion_tokens || 0,
    }).catch(() => {})

    res.json({ result: content, usage })
  } catch (err) {
    console.error(`Agent [${agent}] error:`, err.message)
    res.status(500).json({ error: `${agent} 出错: ${err.message}` })
  }
})

export default router
