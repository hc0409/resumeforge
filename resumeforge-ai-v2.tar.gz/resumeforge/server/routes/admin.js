import { Router } from 'express'
import supabase from '../services/supabase.js'
import { authRequired } from '../middleware/auth.js'

const router = Router()

// Simple admin check via query param for now
// In production, use proper admin auth
function checkAdmin(req, res, next) {
  // Accept admin key from header or use auth middleware
  const adminKey = req.headers['x-admin-key']
  if (adminKey === process.env.JWT_SECRET) {
    return next()
  }
  return res.status(403).json({ error: '管理员权限不足' })
}

// ── Get system config ──
router.get('/config', checkAdmin, async (req, res) => {
  res.json({
    priceResume: process.env.PRICE_RESUME || '1.99',
    priceInterview: process.env.PRICE_INTERVIEW || '69.9',
    freeCredits: process.env.FREE_CREDITS || '1',
    apiKeyConfigured: !!process.env.SILICONCLOUD_API_KEY,
  })
})

// ── Get usage stats ──
router.get('/stats', checkAdmin, async (req, res) => {
  const { count: userCount } = await supabase
    .from('users')
    .select('*', { count: 'exact', head: true })

  const { data: logs } = await supabase
    .from('usage_logs')
    .select('tokens_in, tokens_out, agent')
    .order('created_at', { ascending: false })
    .limit(500)

  const totalTokensIn = logs?.reduce((s, l) => s + (l.tokens_in || 0), 0) || 0
  const totalTokensOut = logs?.reduce((s, l) => s + (l.tokens_out || 0), 0) || 0

  // Agent breakdown
  const agentStats = {}
  logs?.forEach(l => {
    if (!agentStats[l.agent]) agentStats[l.agent] = { count: 0, tokensIn: 0, tokensOut: 0 }
    agentStats[l.agent].count++
    agentStats[l.agent].tokensIn += l.tokens_in || 0
    agentStats[l.agent].tokensOut += l.tokens_out || 0
  })

  res.json({
    userCount,
    totalCalls: logs?.length || 0,
    totalTokensIn,
    totalTokensOut,
    agentStats,
  })
})

// ── Add credits to user (manual charge after scan-to-pay) ──
router.post('/add-credits', checkAdmin, async (req, res) => {
  const { phone, credits, type } = req.body

  const { data: user } = await supabase
    .from('users')
    .select('*')
    .eq('phone', phone)
    .single()

  if (!user) return res.status(404).json({ error: '用户不存在' })

  if (type === 'interview') {
    await supabase
      .from('users')
      .update({ interview_credits: (user.interview_credits || 0) + (credits || 1) })
      .eq('id', user.id)
  } else {
    await supabase
      .from('users')
      .update({ credits: user.credits + (credits || 1) })
      .eq('id', user.id)
  }

  res.json({ ok: true, message: `已为 ${phone} 充值 ${credits || 1} 次` })
})

export default router
