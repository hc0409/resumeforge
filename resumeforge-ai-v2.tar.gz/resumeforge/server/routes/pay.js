import { Router } from 'express'
import supabase from '../services/supabase.js'
import { authRequired } from '../middleware/auth.js'

const router = Router()

// ── Create order (scan-to-pay) ──
router.post('/create', authRequired, async (req, res) => {
  const { type } = req.body // 'resume' or 'interview'
  const price = type === 'interview'
    ? parseFloat(process.env.PRICE_INTERVIEW || '69.9')
    : parseFloat(process.env.PRICE_RESUME || '1.99')

  const orderId = `RF${Date.now()}${Math.random().toString(36).slice(2, 6).toUpperCase()}`

  await supabase.from('orders').insert({
    id: orderId,
    user_id: req.userId,
    type,
    amount: price,
    status: 'pending',
  })

  res.json({
    orderId,
    amount: price,
    type,
    // In future: return wechat pay QR code URL
    payMethod: 'scan_transfer',
    qq: '2740035240',
  })
})

// ── Check order status ──
router.get('/check/:orderId', authRequired, async (req, res) => {
  const { data: order } = await supabase
    .from('orders')
    .select('*')
    .eq('id', req.params.orderId)
    .eq('user_id', req.userId)
    .single()

  if (!order) return res.status(404).json({ error: '订单不存在' })
  res.json({ order })
})

export default router
