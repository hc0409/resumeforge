import { Router } from 'express'
import { fetchAvailableModels, DEFAULT_MODELS } from '../services/ai.js'

const router = Router()

let cachedModels = null
let cachedAt = 0
const CACHE_TTL = 10 * 60 * 1000 // 10 minutes

router.get('/', async (req, res) => {
  // Return cached if fresh
  if (cachedModels && Date.now() - cachedAt < CACHE_TTL) {
    return res.json({ models: cachedModels, defaults: DEFAULT_MODELS })
  }

  const models = await fetchAvailableModels()
  if (models.length > 0) {
    cachedModels = models
    cachedAt = Date.now()
  }

  res.json({
    models: cachedModels || [],
    defaults: DEFAULT_MODELS,
  })
})

export default router
