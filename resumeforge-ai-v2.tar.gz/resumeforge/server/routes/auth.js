import { Router } from 'express'
import supabase from '../services/supabase.js'
import { authRequired, generateToken } from '../middleware/auth.js'
import dotenv from 'dotenv'
dotenv.config()

const router = Router()
const FREE_CREDITS = parseInt(process.env.FREE_CREDITS || '1')

// ── Send verification code (simplified — just store code in DB) ──
router.post('/send-code', async (req, res) => {
  const { phone } = req.body
  if (!phone || phone.length !== 11) {
    return res.status(400).json({ error: '请输入11位手机号' })
  }

  // Generate 6-digit code
  const code = String(Math.floor(100000 + Math.random() * 900000))

  // Store code in DB (expires in 5 min)
  await supabase.from('verify_codes').upsert({
    phone,
    code,
    expires_at: new Date(Date.now() + 5 * 60 * 1000).toISOString(),
  }, { onConflict: 'phone' })

  // TODO: 接入真实短信服务 (阿里云/腾讯云)
  // 目前验证码固定为 123456 方便测试
  console.log(`📱 验证码 [${phone}]: ${code}`)

  res.json({ ok: true, message: '验证码已发送' })
})

// ── Phone login ──
router.post('/login', async (req, res) => {
  const { phone, code } = req.body
  if (!phone || !code) {
    return res.status(400).json({ error: '手机号和验证码不能为空' })
  }

  // Check code (accept 123456 as universal test code)
  if (code !== '123456') {
    const { data: codeRow } = await supabase
      .from('verify_codes')
      .select('*')
      .eq('phone', phone)
      .gt('expires_at', new Date().toISOString())
      .single()

    if (!codeRow || codeRow.code !== code) {
      return res.status(400).json({ error: '验证码错误或已过期' })
    }
  }

  // Find or create user
  let { data: user } = await supabase
    .from('users')
    .select('*')
    .eq('phone', phone)
    .single()

  if (!user) {
    const { data: newUser } = await supabase
      .from('users')
      .insert({
        phone,
        credits: FREE_CREDITS,
        is_admin: false,
      })
      .select()
      .single()
    user = newUser
  }

  const token = generateToken(user.id, user.is_admin)
  res.json({ user, token })
})

// ── Guest login ──
router.post('/guest', async (req, res) => {
  const guestId = 'guest_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8)

  const { data: user } = await supabase
    .from('users')
    .insert({
      phone: null,
      name: guestId,
      credits: FREE_CREDITS,
      is_admin: false,
    })
    .select()
    .single()

  const token = generateToken(user.id, false)
  res.json({ user, token })
})

// ── Get current user ──
router.get('/me', authRequired, async (req, res) => {
  const { data: user } = await supabase
    .from('users')
    .select('*')
    .eq('id', req.userId)
    .single()

  if (!user) return res.status(404).json({ error: '用户不存在' })
  res.json({ user })
})

export default router
