import { Router } from 'express'
import supabase from '../services/supabase.js'
import { callAI, DEFAULT_MODELS } from '../services/ai.js'
import { authRequired } from '../middleware/auth.js'
import PROMPTS from '../prompts/index.js'

const router = Router()

router.post('/run', authRequired, async (req, res) => {
  const { resume, jd } = req.body

  if (!resume) {
    return res.status(400).json({ error: '请输入简历' })
  }

  // Check interview credits
  const { data: user } = await supabase
    .from('users')
    .select('interview_credits')
    .eq('id', req.userId)
    .single()

  if (!user || (user.interview_credits || 0) <= 0) {
    return res.status(402).json({ error: '面试辅导次数不足，请先充值（¥69.9/次）' })
  }

  // Deduct
  await supabase
    .from('users')
    .update({ interview_credits: (user.interview_credits || 0) - 1 })
    .eq('id', req.userId)

  try {
    // Multi-AI collaboration
    const results = {}

    // Step 1: Main coaching (MiniMax)
    const { content: coaching } = await callAI(
      DEFAULT_MODELS.coach,
      PROMPTS.coach,
      `简历:\n${resume}\n\n目标JD:\n${jd || '(未提供)'}`,
      { maxTokens: 6000 }
    )
    results.coaching = coaching

    // Step 2: Salary negotiation (DeepSeek)
    const { content: salary } = await callAI(
      DEFAULT_MODELS.analyzer,
      PROMPTS.interview_salary,
      `简历:\n${resume}\n\n目标JD:\n${jd || '(未提供)'}`,
      { maxTokens: 4096 }
    )
    results.salary = salary

    // Step 3: Reverse thinking (GLM)
    const { content: reverse } = await callAI(
      DEFAULT_MODELS.polisher,
      PROMPTS.interview_reverse,
      `简历:\n${resume}\n\n目标JD:\n${jd || '(未提供)'}`,
      { maxTokens: 4096 }
    )
    results.reverse = reverse

    res.json({ results })
  } catch (err) {
    console.error('Interview error:', err.message)
    res.status(500).json({ error: err.message })
  }
})

export default router
