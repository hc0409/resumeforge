import dotenv from 'dotenv'
dotenv.config()

const API_BASE = 'https://api.siliconflow.cn/v1'

// ── Default model assignments ──
export const DEFAULT_MODELS = {
  analyzer:  'Pro/deepseek-ai/DeepSeek-V3.2',
  matcher:   'Pro/moonshotai/Kimi-K2.5',
  optimizer: 'Qwen/Qwen3.5-122B-A22B',
  polisher:  'Pro/zhipuai/GLM-5.1',
  coach:     'Pro/MiniMaxAI/MiniMax-M2.5',
  verifier:  'Pro/deepseek-ai/DeepSeek-V3.2',
  scorer:    'Pro/moonshotai/Kimi-K2.5',
}

export async function callAI(model, systemPrompt, userMessage, options = {}) {
  const apiKey = process.env.SILICONCLOUD_API_KEY
  if (!apiKey) throw new Error('未配置 SILICONCLOUD_API_KEY')

  const res = await fetch(`${API_BASE}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userMessage },
      ],
      max_tokens: options.maxTokens || 4096,
      temperature: options.temperature || 0.7,
      stream: false,
    }),
    signal: options.signal,
  })

  if (!res.ok) {
    const err = await res.json().catch(() => ({}))
    throw new Error(err.error?.message || `API ${res.status}`)
  }

  const data = await res.json()
  const content = data.choices?.[0]?.message?.content || ''
  const usage = data.usage || {}

  return { content, usage }
}

// ── Fetch latest models from SiliconCloud ──
export async function fetchAvailableModels() {
  const apiKey = process.env.SILICONCLOUD_API_KEY
  if (!apiKey) return []

  try {
    const res = await fetch(`${API_BASE}/models`, {
      headers: { 'Authorization': `Bearer ${apiKey}` },
    })
    if (!res.ok) return []
    const data = await res.json()
    return (data.data || []).map(m => ({
      id: m.id,
      name: m.id.split('/').pop(),
      owned_by: m.owned_by || '',
    }))
  } catch {
    return []
  }
}
