# ResumeForge AI

> 智能简历优化平台 — 6大AI全自动流水线，让每一份简历都值得一个面试机会

## 技术栈

- **前端**: Vite + React 18 + React Router
- **后端**: Node.js + Express
- **数据库**: Supabase (PostgreSQL)
- **AI引擎**: SiliconCloud (DeepSeek-V3.2 / Kimi-K2.5 / Qwen3.5 / GLM-5.1 / MiniMax-M2.5)
- **部署**: Vercel

## 快速开始

```bash
# 1. 安装依赖
npm install
cd client && npm install
cd ../server && npm install
cd ..

# 2. 配置环境变量
cp server/.env.example server/.env
# 编辑 .env 填写你的密钥

# 3. 启动开发服务器
npm run dev
```

## 功能

- ✅ 白色 iOS 风格 UI
- ✅ 求职心理引导页
- ✅ 6大AI全自动流水线
- ✅ STAR强化 + 老社畜写法 + 三无策略
- ✅ 简历无 * 号、青色胶囊标题排版
- ✅ 面试辅导模块 (¥69.9/次)
- ✅ 扫码支付 ¥1.99/次
- ✅ 多格式文件导入 (txt/pdf/docx/图片)
- ✅ 模型实时同步 SiliconCloud
- ✅ Token 数据可视化
- ✅ 管理后台 (定价/充值/统计)

## 反馈

QQ: 2740035240
